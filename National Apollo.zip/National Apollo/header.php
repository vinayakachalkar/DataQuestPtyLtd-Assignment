<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2.0">
      <!-- Bootstrap core CSS -->
      <link rel="stylesheet" href="assets/css/bootstrap.min.css">
      <script src="assets/js/jquery-3.2.1.slim.min.js"></script>
      <script src="assets/js/popper.min.js"></script>
      <script src="assetsjs/bootstrap.min.js"></script>
      <link href="assets/css/font-awesome.min.css" rel="stylesheet">
      <title>Assignment</title>
      <link rel='stylesheet'  href='assets/css/style3.css' />
      <link rel='stylesheet'  href='assets/css/style4.css' />
      <style id='storefront-style-inline-css'>
         .main-navigation ul li a,
         .site-title a,
         ul.menu li a,
         .site-branding h1 a,
         button.menu-toggle,
         button.menu-toggle:hover,
         .handheld-navigation .dropdown-toggle {
         color: #333333;
         }
         button.menu-toggle,
         button.menu-toggle:hover {
         border-color: #333333;
         }
         .main-navigation ul li a:hover,
         .main-navigation ul li:hover > a,
         .site-title a:hover,
         .site-header ul.menu li.current-menu-item > a {
         color: #747474;
         }
         table:not( .has-background ) th {
         background-color: #f8f8f8;
         }
         table:not( .has-background ) tbody td {
         background-color: #fdfdfd;
         }
         table:not( .has-background ) tbody tr:nth-child(2n) td,
         fieldset,
         fieldset legend {
         background-color: #fbfbfb;
         }
         .site-header,
         .secondary-navigation ul ul,
         .main-navigation ul.menu > li.menu-item-has-children:after,
         .secondary-navigation ul.menu ul,
         .storefront-handheld-footer-bar,
         .storefront-handheld-footer-bar ul li > a,
         .storefront-handheld-footer-bar ul li.search .site-search,
         button.menu-toggle,
         button.menu-toggle:hover {
         background-color: #ffffff;
         }
         p.site-description,
         .site-header,
         .storefront-handheld-footer-bar {
         color: #404040;
         }
         button.menu-toggle:after,
         button.menu-toggle:before,
         button.menu-toggle span:before {
         background-color: #333333;
         }
         h1, h2, h3, h4, h5, h6, .wc-block-grid__product-title {
         color: #333333;
         }
         .widget h1 {
         border-bottom-color: #333333;
         }
         body,
         .secondary-navigation a {
         color: #6d6d6d;
         }
         .widget-area .widget a,
         .hentry .entry-header .posted-on a,
         .hentry .entry-header .post-author a,
         .hentry .entry-header .post-comments a,
         .hentry .entry-header .byline a {
         color: #727272;
         }
         a {
         color: #96588a;
         }
         a:focus,
         button:focus,
         .button.alt:focus,
         input:focus,
         textarea:focus,
         input[type="button"]:focus,
         input[type="reset"]:focus,
         input[type="submit"]:focus,
         input[type="email"]:focus,
         input[type="tel"]:focus,
         input[type="url"]:focus,
         input[type="password"]:focus,
         input[type="search"]:focus {
         outline-color: #96588a;
         }
         .site-footer {
         background-color: #f0f0f0;
         color: #6d6d6d;
         }
         .site-footer a:not(.button):not(.components-button) {
         color: #333333;
         }
         .site-footer .storefront-handheld-footer-bar a:not(.button):not(.components-button) {
         color: #333333;
         }
         .site-footer h1, .site-footer h2, .site-footer h3, .site-footer h4, .site-footer h5, .site-footer h6, .site-footer .widget .widget-title, .site-footer .widget .widgettitle {
         color: #333333;
         }
         .page-template-template-homepage.has-post-thumbnail .type-page.has-post-thumbnail .entry-title {
         color: #000000;
         }
         .page-template-template-homepage.has-post-thumbnail .type-page.has-post-thumbnail .entry-content {
         color: #000000;
         }
         @media screen and ( min-width: 768px ) {
         .secondary-navigation ul.menu a:hover {
         color: #595959;
         }
         .secondary-navigation ul.menu a {
         color: #404040;
         }
         .main-navigation ul.menu ul.sub-menu,
         .main-navigation ul.nav-menu ul.children {
         background-color: #f0f0f0;
         }
         .site-header {
         border-bottom-color: #f0f0f0;
         }
         }
      </style>
      <link rel='stylesheet' id='storefront-woocommerce-style-css'  href='assets/css/style2.css' media='all' />
      <style id='storefront-woocommerce-style-inline-css'>
         a.cart-contents,
         .site-header-cart .widget_shopping_cart a {
         color: #333333;
         }
         a.cart-contents:hover,
         .site-header-cart .widget_shopping_cart a:hover,
         .site-header-cart:hover > li > a {
         color: #747474;
         }
         table.cart td.product-remove,
         table.cart td.actions {
         border-top-color: #ffffff;
         }
         .storefront-handheld-footer-bar ul li.cart .count {
         background-color: #333333;
         color: #ffffff;
         border-color: #ffffff;
         }
         .woocommerce-tabs ul.tabs li.active a,
         ul.products li.product .price,
         .onsale,
         .wc-block-grid__product-onsale,
         .widget_search form:before,
         .widget_product_search form:before {
         color: #6d6d6d;
         }
         .woocommerce-breadcrumb a,
         a.woocommerce-review-link,
         .product_meta a {
         color: #727272;
         }
         .wc-block-grid__product-onsale,
         .onsale {
         border-color: #6d6d6d;
         }
         .star-rating span:before,
         .quantity .plus, .quantity .minus,
         p.stars a:hover:after,
         p.stars a:after,
         .star-rating span:before,
         #payment .payment_methods li input[type=radio]:first-child:checked+label:before {
         color: #96588a;
         }
         .widget_price_filter .ui-slider .ui-slider-range,
         .widget_price_filter .ui-slider .ui-slider-handle {
         background-color: #96588a;
         }
         .order_details {
         background-color: #f8f8f8;
         }
         .order_details > li {
         border-bottom: 1px dotted #e3e3e3;
         }
         .order_details:before,
         .order_details:after {
         background: -webkit-linear-gradient(transparent 0,transparent 0),-webkit-linear-gradient(135deg,#f8f8f8 33.33%,transparent 33.33%),-webkit-linear-gradient(45deg,#f8f8f8 33.33%,transparent 33.33%)
         }
         #order_review {
         background-color: #ffffff;
         }
         #payment .payment_methods > li .payment_box,
         #payment .place-order {
         background-color: #fafafa;
         }
         #payment .payment_methods > li:not(.woocommerce-notice) {
         background-color: #f5f5f5;
         }
         #payment .payment_methods > li:not(.woocommerce-notice):hover {
         background-color: #f0f0f0;
         }
         .woocommerce-pagination .page-numbers li .page-numbers.current {
         background-color: #e6e6e6;
         color: #636363;
         }
         .wc-block-grid__product-onsale,
         .onsale,
         .woocommerce-pagination .page-numbers li .page-numbers:not(.current) {
         color: #6d6d6d;
         }
         @media screen and ( min-width: 768px ) {
         .site-header-cart .widget_shopping_cart,
         .site-header .product_list_widget li .quantity {
         color: #404040;
         }
         .site-header-cart .widget_shopping_cart .buttons,
         .site-header-cart .widget_shopping_cart .total {
         background-color: #f5f5f5;
         }
         .site-header-cart .widget_shopping_cart {
         background-color: #f0f0f0;
         }
         }
         .storefront-product-pagination a {
         color: #6d6d6d;
         background-color: #ffffff;
         }
         .storefront-sticky-add-to-cart {
         color: #6d6d6d;
         background-color: #ffffff;
         }
         .storefront-sticky-add-to-cart a:not(.button) {
         color: #333333;
         }
      </style>
      <link rel='stylesheet' id='storefront-child-style-css'  href='assets/css/style.css' media='all' />
   </head>
    <body class="home">

    
