<footer id="colophon" class="site-footer" role="contentinfo">
         <div class="container">
            <div class="footer-widgets row fix">
               <div class="block tt footer-widget-1 col-4">
                  <div id="text-15" class="widget widget_text">
                     <div class="textwidget">
                        <h2 class="footer-logo">National Apollo</h2>
                        <h4 class="footer-logo-pre">Bathrooms</h4>
                        <p>National Apollo is an Australian-owned supplier of bathroom, kitchen and laundry improvement products servicing trade and DIY customers since 2002.</p>
                     </div>
                  </div>
               </div>
               <div class="block tt2 footer-widget-2 col-2">
                  <div id="nav_menu-7" class="widget widget_nav_menu">
                     <span class="gamma widget-title">Products</span>
                     <div class="menu-footer-products-container">
                        <ul id="menu-footer-products" class="menu">
                           <li id="menu-item-11306" class="menu-item"><a href="#">Glass Solution</a></li>
                           <li id="menu-item-11236" class="menu-item "><a href="#">Bathroom</a></li>
                           <li id="menu-item-11237" class="menu-item "><a href="#">Colour Trend</a></li>
                           <li id="menu-item-11238" class="menu-item "><a href="#">Commercial</a></li>
                           <li id="menu-item-11239" class="menu-item "><a href="#">Kitchen</a></li>
                           <li id="menu-item-11240" class="menu-item "><a href="#">Laundry</a></li>
                           <li id="menu-item-11241" class="menu-item "><a href="https://nationalapollo.com.au/product-category/shower-and-steam-cubicle/">Shower &#038; Steam Cubicle</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="block tt1 footer-widget-3 col-2">
                  <div id="nav_menu-8" class="widget widget_nav_menu">
                     <span class="gamma widget-title">Quick Links</span>
                     <div class="menu-footer-quick-links-container">
                        <ul id="menu-footer-quick-links" class="menu">
                           <li id="menu-item-11017" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11017"><a href="#">About Us</a></li>
                           <li id="menu-item-11016" class="menu-item "><a href="#">Contact Us</a></li>
                           <li id="menu-item-11015" class="menu-item"><a href="#">Refund Policy</a></li>
                           <li id="menu-item-11014" class="menu-item "><a href="#">Terms and Conditions</a></li>
                           <li id="menu-item-11018" class="menu-item"><a href="#">Privacy Policy</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="block tt footer-widget-4 col-4">
                  <div id="dq_widget-2" class="widget widget_dq_widget">
                     <span class="gamma widget-title">Contact Us</span>            
                     <ul class="footer-contact-widget">
                        <li class="footer-phone">Phone: <a href="#">+61 2 9682 7500</a></li>
                        <li class="footer-email">Email: <a></a></li>
                        <li class="footer-address">
                           <p>44 Parramatta Road<br />(Parking at Berry Street)<br />Clyde NSW 2142 Australia</p>
                        </li>
                     </ul>
                  </div>
                  <div id="newsletterwidget-2" class="widget widget_newsletterwidget">
                     <span class="gamma widget-title">Subscribe to our newsletter</span>
                     <div class="tnp tnp-widget">
                        <form method="post" >
                           <input type="hidden" name="nlang" value="">
                           <input type="hidden" name="nr" value="widget">
                           <input type='hidden' name='nl[]' value='0'>
                           <div class="tnp-field tnp-field-email"><label>Email</label><input class="tnp-email" type="email" name="ne" required></div>
                           <div class="tnp-field tnp-field-button"><input class="tnp-submit" type="button" value="Subscribe" ></div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
            <div class="site-info clearfix">
               <div class="text-left">Powered by <a href="#" target="_blank">DataQuest Digital</a></div>
               <div class="text-right">Copyright &copy; 2021 National Apollo. All Rights Reserved.</div>
            </div>
         </div>
         <script>
            $(document).ready(function () {
                //Show then hide ddown menu on hover
                $('#header-account .icons-area div.account1').hover(function () {
                    $( '.menu-account-menu-container' ).show();
                }, function () {
                    $( '.menu-account-menu-container' ).hide();
                });
            });
         </script>
   </body>
</html>