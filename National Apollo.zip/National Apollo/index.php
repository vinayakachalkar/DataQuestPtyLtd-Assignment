
  <?php 
  include('header.php');
  ?> 
      <header id="masthead" class="site-header navbar fixed-top" role="banner" style="">
         <div class="container-fluid" id="header-top">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 col-sm-8 col-xs-12 header_top_left">
                     <a href="">
                        <p class="header-phone">Call us Today : +61 2 9682 7500</p>
                     </a>
                     <a >
                        <p class="header-email">enquiries@nationalapollo.com.au</p>
                     </a>
                  </div>
                  <div class="col-4 d-none d-sm-block header_top_center">
                     <div class="menu-header-top-menu-container">
                        <ul id="menu-header-top-menu" class="menu">
                           <li id="menu-item-11020" class="menu-item "><a href="#"><p class="header-email">National Warranty</p></a></li>
                           <li id="menu-item-11021" class="menu-item "><a href="#"><p class="header-email">National Delivery</p></a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-12 d-block d-sm-none header_top_right" id="header-account">
                     <div class="icons-area test">
                        <ul class="account test">
                           <li>
                              <div class="account1"><a class="nav-item" href="#"><img src="https://nationalapollo.com.au/wp-content/themes/storefront-child/img/user_icon.png" /></a>
                              </div>
                           </li>
                           <li><a class="nav-item" href="#"><img src="https://nationalapollo.com.au/wp-content/themes/storefront-child/img/wishlist_icon.png" /></a></li>
                           <li>
                              <ul id="site-header-cart" class="site-header-cart menu">
                                 <li class="">
                                    <a class="cart-contents" href="#" title="View your shopping cart">
                                    <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#036;</span>0.00</span> <span class="count">0 items</span>
                                    </a>
                                 </li>
                                 <li>
                                    <div class="widget woocommerce widget_shopping_cart">
                                       <div class="widget_shopping_cart_content"></div>
                                    </div>
                                 </li>
                              </ul>
                           </li>
                           <li>
                              <p class="nav-item mobile-search" id="main-nav-search-btn"><i class="fa fa-search"></i></p>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="sticky-top container-fluid" id="header-bottom">
            <div class="container">
               <div class="row">
                  <div class="col-2 header-logo">
                     <a href='#'><img src='assets/images/nationalapollo-LOGO白底蓝字-scaled.jpg' alt='logo'/></a>        
                  </div>
                  <div class="col-8" id="header-menu">
                     <div class="storefront-primary-navigation">
                        <div class="col-full">
                           <nav id="site-navigation" class="main-navigation" role="navigation" aria-label="Primary Navigation">
                              <button class="menu-toggle" aria-controls="site-navigation" aria-expanded="false"><span>Menu</span></button>
                              <div id="mega-menu-wrap-primary" class="mega-menu-wrap">
                                 <div class="mega-menu-toggle">
                                    <div class="mega-toggle-blocks-left"></div>
                                    <div class="mega-toggle-blocks-center"></div>
                                    <div class="mega-toggle-blocks-right">
                                       <div class='mega-toggle-block mega-menu-toggle-animated-block mega-toggle-block-0' id='mega-toggle-block-0'><button aria-label="Toggle Menu" class="mega-toggle-animated mega-toggle-animated-slider" type="button" aria-expanded="false">
                                          <span class="mega-toggle-animated-box">
                                          <span class="mega-toggle-animated-inner"></span>
                                          </span>
                                          </button>
                                       </div>
                                    </div>
                                 </div>
                                 <ul id="mega-menu-primary" class="mega-menu">
                                    <li class='mega-menu-item'  id='mega-menu-item-8879'><a class="mega-menu-link" href="#" tabindex="0">Home</a></li>
                                    <li class='mega-menu-item' id='mega-menu-item-8923'><a class="mega-menu-link" href="#" aria-haspopup="true" aria-expanded="false" tabindex="0">Services<span class="mega-indicator"></span></a>
                                    </li>
                                    <li class='mega-menu-item' id='mega-menu-item-8882'>
                                       <a class="mega-menu-link" href="" aria-haspopup="true" aria-expanded="false" tabindex="0">Products<span class="mega-indicator"></span></a>
                                    </li>
                                    <li class='mega-menu-item ' id='mega-menu-item-8884'><a class="mega-menu-link" href="#" tabindex="0">Gallery</a></li>
                                    <li class='mega-menu-item' id='mega-menu-item-8883'><a class="mega-menu-link" href="#" tabindex="0">About Us</a></li>
                                    <li class='mega-menu-item' id='mega-menu-item-8880'><a class="mega-menu-link" href="#" tabindex="0">Contact Us</a></li>
                                    
                                 </ul>
                              </div>
                              <div class="menu">
                                 <ul>
                                    <li class="page_item page-item-5"><a href="#">Cart</a></li>
                                    <li class="page_item page-item-6"><a href="#">Checkout</a></li>
                                    <li class="page_item page-item-2148"><a href="#">Contact Us</a></li>
                                    <li class="page_item page-item-8827"><a href="#">Delivery Information</a></li>
                                    <li class="page_item page-item-11332"><a href="#">FAQ</a></li>
                                    <
                                    </li>
                                 </ul>
                              </div>
                           </nav>
                           <!-- #site-navigation -->
                        </div>
                     </div>
                  </div>
                  <div class="col-2 d-none d-sm-block" id="header-account">
                     <div class="icons-area test1">
                        <ul class="account test1">
                           <li>
                              <div class="account1"><a class="nav-item" href="#"><img src="assets/images/user_icon.png" /></a>
                              </div>
                           </li>
                           <li>
                              <a class="wishlist_count nav-item" href="#"><img src="assets/images/wishlist_icon.png" />
                              </a>                                      
                           </li>
                           
                           <li>
                              <p class="nav-item desktop-search" id="main-nav-search-btn"><i class="fa fa-search"></i></p>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <div id="content" class="site-content" tabindex="-1">
         <main role="main">
            <div id="home-offer">
               <div class="container">
                  <div class="py-1 text-center row justify-content-center">
                     <div class="col-6 col-sm-12 col-md-6">
                        <div class="separator"> What we offer </div>
                     </div>
                  </div>
                  <div class="text-center row justify-content-center">
                     <div class="col-7 col-sm-12 col-md-7">
                        <p>National Apollo helps customers across Australia create beautiful bathrooms, kitchens, laundries and outdoor spaces that increase the value of your home.</p>
                     </div>
                  </div>
               </div>
               <div class="container" id="home-product-cat">
                  <div class="row">
                     <div class="col-12">
                        <div class="row" id="home-cat">
                           <div class='col-4 col-sm-12 col-md-4'>
                              <div class='cate-inner'>
                                 <div class='product-image'><img src="assets/images/Bathroom-Products.png" alt="Bathroom" /></div>
                                 <p class='product-title'>Bathroom</p>
                                 <a class="btn yellow-btn btn-lg" style="color: #ffffff;">View products <img src="assets/images/angle_right_icon.png" alt="arrow" /></a>
                              </div>
                           </div>
                           <div class='col-4 col-sm-12 col-md-4'>
                              <div class='cate-inner'>
                                 <div class='product-image'><img src="assets/images/Colour-Trend.png" alt="Colour Trend" /></div>
                                 <p class='product-title'>Colour Trend</p>
                                 <a href="#" class="btn yellow-btn btn-lg">View products <img src="assets/images/angle_right_icon.png" alt="arrow" /></a>
                              </div>
                           </div>
                           <div class='col-4 col-sm-12 col-md-4'>
                              <div class='cate-inner'>
                                 <div class='product-image'><img src="assets/images/Commercial.png" alt="Commercial" /></div>
                                 <p class='product-title'>Commercial</p>
                                 <a href="#" class="btn yellow-btn btn-lg">View products <img src="assets/images/angle_right_icon.png" alt="arrow" /></a>
                              </div>
                           </div>
                           <div class='col-4 col-sm-12 col-md-4'>
                              <div class='cate-inner'>
                                 <div class='product-image'><img src="assets/images/Kitchen-Products.png" alt="Kitchen" /></div>
                                 <p class='product-title'>Kitchen</p>
                                 <a href="#" class="btn yellow-btn btn-lg">View products <img src="assets/images/angle_right_icon.png" alt="arrow" /></a>
                              </div>
                           </div>
                           <div class='col-4 col-sm-12 col-md-4'>
                              <div class='cate-inner'>
                                 <div class='product-image'><img src="assets/images/Laundry.png" alt="Laundry" /></div>
                                 <p class='product-title'>Laundry</p>
                                 <a href="#" class="btn yellow-btn btn-lg">View products <img src="assets/images/angle_right_icon.png" alt="arrow" /></a>
                              </div>
                           </div>
                           <div class='col-4 col-sm-12 col-md-4'>
                              <div class='cate-inner'>
                                 <div class='product-image'><img src="assets/images/Shower-Steam-Cubicles.png" alt="Shower &amp; Steam Cubicle" /></div>
                                 <p class='product-title'>Shower &amp; Steam Cubicle</p>
                                 <a href="#" class="btn yellow-btn btn-lg">View products <img src="assets/images/angle_right_icon.png" alt="arrow" /></a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </main>
      </div>
       <?php 
  include('footer.php');
  ?> 
      
      